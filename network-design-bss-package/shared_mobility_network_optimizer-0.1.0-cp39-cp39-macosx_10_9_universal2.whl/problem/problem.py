


# problem 中考虑 demand，最终构建的graph G 等，将其转变为 gurobi 模型的输入可以利用的一些形式
# 生成 demand 后 有一步可以减少网络规模，即 od 没有的 则不需要考虑任何路径
# demand 生成方式也考虑 越中心的点生成的demand 越多，靠近地铁线路的点 demand 越多




