from input_handler.preprocess import preprocess
from output_handler import Visualize, VisualizeMap
from model.bike_sharing_optimization import BikeSharingModel
from network.network_constructor import NetworkConstructor
from shortest_path.shortest_path_solver import ShortestPathSolver
from datetime import datetime
from util.util import init_tunable_params
from .models import NetworkDesignBSSConfig

class SharedMobilityNetworkOptimizer:
    """
    A high-level interface for optimizing a shared mobility network using a bilevel programming model.

    This class handles the full pipeline: preprocessing input data, building the transport network,
    solving shortest paths, running the optimization model, visualizing results, and exporting data.

    Attributes:
        config (NetworkDesignBSSConfig): Configuration parameters for the simulation area and model.
    """

    def __init__(self, config: NetworkDesignBSSConfig):
        """
        Initializes the optimizer with the given configuration.

        Args:
            config (NetworkDesignBSSConfig): Configuration object containing simulation parameters.
        """
        self.config = config
        tp = init_tunable_params(config)
        self.AREA_LENGTH = tp.AREA_LENGTH
        self.AREA_WIDTH = tp.AREA_WIDTH
        self.CELL_SIZE = tp.CELL_SIZE
        self.NUM_SHORTEST_PATHS = config.NUM_SHORTEST_PATHS

        self.grid_generator = None
        self.public_transport = None
        self.bike_stations = None
        self.demand_generator = None
        self.network = None
        self.shortest_path_solver = None
        self.visualizer = None

    def build_network(self):
        """
        Preprocesses input data and constructs the transport network graph.

        This step includes generating the grid, processing public transport and bike station data,
        and computing the shortest paths between relevant nodes.
        """
        print("📦 Preprocessing data")
        grid_generator, public_transport, bike_stations, self.demand_generator = preprocess(
            self.AREA_LENGTH, self.AREA_WIDTH, self.CELL_SIZE
        )

        print("🌐 Constructing transport network")
        self.network = NetworkConstructor(
            grid_generator.grid, grid_generator, public_transport, bike_stations
        )

        print("🚦 Solving shortest paths")
        self.shortest_path_solver = ShortestPathSolver(
            self.network.graph, k=self.NUM_SHORTEST_PATHS
        )

        self.visualizer = Visualize(
            grid_generator=grid_generator,
            pt=public_transport,
            shortest_path_solver=self.shortest_path_solver,
            demand_generator=self.demand_generator,
        )

        self.visualizer_map = VisualizeMap(
            grid_generator=grid_generator,
            pt=public_transport,
            demand_generator=self.demand_generator,
            model=None,
        )

    def optimize(self):
        """
        Runs the internal optimization model to determine optimal bike station placements and flow.

        This method initializes the private BikeSharingModel using the constructed network and
        demand information, and stores the result for visualization and export.
        """
        print("🧠 Running optimization model")
        self.model = BikeSharingModel(
            self.network, self.shortest_path_solver, self.demand_generator
        )
        self.visualizer.model = self.model
        self.visualizer_map.model = self.model

    def plot(self):
        """
        Generates visualizations for the simulation results.

        Plots include the grid layout, nodes, and outputs of the optimization model.
        """
        print("🖼️ Visualizing results")
        self.visualizer.plot_grid()
        self.visualizer.plot_grid_with_nodes()
        # self.visualizer.plot_demand_flow()
        self.visualizer.plot_model_output()

    def to_geojson(self):
        """
        Exports the results of the optimization model to GeoJSON format for mapping.

        Returns:
            dict: A GeoJSON object containing the network and model outputs.
        """
        print("🗺️ Exporting map data")
        self.visualizer_map.export_all()

    def run_pipeline(self):
        """
        Runs the complete pipeline: build the network, optimize, and plot results.

        This is a high-level convenience method for end-to-end execution.
        """
        start_time = datetime.now()
        print(f"🚀 Simulation started at {start_time}")

        self.build_network()
        self.optimize()
        self.plot()

        print(f"✅ Simulation completed in {datetime.now() - start_time}")
