from input_handler.preprocess import preprocess
from output_handler import Visualize, VisualizeMap
from model.bike_sharing_optimization import BikeSharingModel
from network.network_constructor import NetworkConstructor
from shortest_path.shortest_path_solver import ShortestPathSolver
from datetime import datetime
from util.util import  init_tunable_params
from .models import NetworkDesignBSSConfig

class SharedMobilityNetworkOptimizer:
    def __init__(self, 
                 config:NetworkDesignBSSConfig):
        self.config = config
        tp = init_tunable_params(config)
        self.AREA_LENGTH = tp.AREA_LENGTH
        self.AREA_WIDTH = tp.AREA_WIDTH
        self.CELL_SIZE = tp.CELL_SIZE
        self.NUM_SHORTEST_PATHS = config.NUM_SHORTEST_PATHS

        self.grid_generator = None
        self.public_transport = None
        self.bike_stations = None
        self.demand_generator = None
        self.network = None
        self.shortest_path_solver = None
        self.visualizer = None

    def build_network(self):
        print("📦 Preprocessing data")
        grid_generator, public_transport, bike_stations, self.demand_generator = preprocess(
            self.AREA_LENGTH, self.AREA_WIDTH, self.CELL_SIZE
        )

        print("🌐 Constructing transport network")
        self.network = NetworkConstructor(
            grid_generator.grid, grid_generator, public_transport, bike_stations
        )

        print("🚦 Solving shortest paths")
        self.shortest_path_solver = ShortestPathSolver(self.network.graph, k=self.NUM_SHORTEST_PATHS)

        self.visualizer = Visualize(
            grid_generator=grid_generator,
            pt=public_transport,
            shortest_path_solver=self.shortest_path_solver,
            demand_generator=self.demand_generator,
        )

        self.visualizer_map = VisualizeMap(
            grid_generator=grid_generator,
            pt=public_transport,
            demand_generator=self.demand_generator,
            model=None,
        )

    def optimize(self):
        print("🧠 Running optimization model")
        self.model = BikeSharingModel(self.network, self.shortest_path_solver, self.demand_generator)
        self.visualizer.model = self.model
        self.visualizer_map.model = self.model

    def plot(self):
        print("🖼️ Visualizing results")
        self.visualizer.plot_grid()
        self.visualizer.plot_grid_with_nodes()
        #self.visualizer.plot_demand_flow()
        self.visualizer.plot_model_output()

    def to_geojson(self):
        print("🗺️ Exporting map data")
        self.visualizer_map.export_all()

    def run_pipeline(self):
        start_time = datetime.now()
        print(f"🚀 Simulation started at {start_time}")
        
        self.build_network()
        self.optimize()
        self.plot()

        print(f"✅ Simulation completed in {datetime.now() - start_time}")
