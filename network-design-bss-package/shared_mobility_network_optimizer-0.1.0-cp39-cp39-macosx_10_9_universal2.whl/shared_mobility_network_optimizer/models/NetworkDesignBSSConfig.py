from pydantic import BaseModel, Field
from typing import List

class NetworkDesignBSSConfig(BaseModel):
    """
    Configuration parameters for the bike-sharing network simulation model.

    This configuration is designed to be initialized from a JSON object.
    It defines key simulation parameters including area size, transportation speeds, demand, 
    and optimization model settings.
    """

    DATA_PATH: str = Field(
        "data",
        description="Path to the data directory containing input files for the simulation."
    )
    CACHE_PATH: str = Field(
        "cache",
        description="Path to the cache directory for storing intermediate results."
    )

    # Shortest path and optimization parameters
    NUM_SHORTEST_PATHS: int = Field(3, description="Number of shortest paths computed between OD pairs.")
    MAX_RELATIVE_GAP: float = Field(0.2, description="Maximum allowed relative time gap between suboptimal and optimal paths.")
    OD_COVERAGE_RATIO: float = Field(0.9, description="Proportion of OD pairs that must be effectively serviced.")

    # Area dimensions
    AREA_LENGTH: int = Field(8, description="Length of the simulation area in arbitrary units (e.g., km).")
    AREA_WIDTH: int = Field(8, description="Width of the simulation area in arbitrary units (e.g., km).")
    CELL_SIZE: int = Field(1, description="Size of each grid cell in arbitrary units.")

    # Catchment areas
    WALK_CATCHMENT_RADIUS: float = Field(1.0, description="Radius defining walkable area (km). Typical range 0.8 - 1.2 km.")
    RIDE_CATCHMENT_RADIUS: float = Field(4.0, description="Radius defining rideable area (km). Typical range 2.5 - 5 km.")

    # Public transport parameters
    PT_TRANSFER_RADIUS: float = Field(0.5, description="Maximum distance allowed for transfers between PT modes (km).")

    # Speeds (km/h)
    WALK_SPEED: float = Field(5.0, description="Average walking speed (km/h). Typical range 4.5 - 5 km/h.")
    RIDE_SPEED: float = Field(15.0, description="Average biking speed (km/h). Typical range 12 - 18 km/h.")
    PUBLIC_TRANSPORT_SPEED: float = Field(30.0, description="Average public transport speed (km/h). Typical range 20 - 35 km/h.")
    CAR_SPEED: float = Field(45.0, description="Average car speed (km/h). Typical range 35 - 50 km/h.")

    # Demand parameters
    TOTAL_TRIPS_NUM: int = Field(1000, description="Total number of trips to simulate for one period.")
    TIME_PERIODS: int = Field(3, description="Number of time periods in the simulation.")

    # Penalty and optimization
    PENALTY_COEFFICIENT: float = Field(0.1, description="Penalty coefficient for suboptimal path choices.")

    # Bike station parameters
    CAPACITY_UB: int = Field(30, description="Capacity upper bound for each bike station.")

    # Fixed public transport routes
    FIXED_LINE_POINTS_LST: List[List[int]] = Field([[10, 18, 27, 1, 36, 45, 53], [22, 21, 28, 1, 35, 42, 41]], description="Predefined fixed-line PT station indices.")

    # Rebalancing options
    REBALANCING_FLAG: bool = Field(True, description="Flag indicating whether rebalancing of bikes is considered.")

