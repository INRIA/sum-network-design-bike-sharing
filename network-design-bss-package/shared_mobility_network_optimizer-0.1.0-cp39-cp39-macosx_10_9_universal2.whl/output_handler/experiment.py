import pandas as pd
import os
from model.bike_sharing_optimization import BikeSharingModel
from network.network_constructor import NetworkConstructor
from util.util import *
from util.cost import CostParameters


class ExperimentHandler:
    def __init__(self,
                 bike_sharing_model: BikeSharingModel,
                 network: NetworkConstructor,
                 config_name: str,
                 output_file="experiment_results.csv"):
        tp = get_tunable_params()
        self.TOTAL_TRIPS_NUN = tp.TOTAL_TRIPS_NUN
        self.TIME_PERIODS = tp.TIME_PERIODS
        self.bike_sharing_model = bike_sharing_model
        self.network = network
        self.config_name = config_name
        self.output_file = output_file
        self.columns = OUTPUT_COLUMNS
        self.data = []
        self._record_experiment_result()

    def _record_experiment_result(self):
        self.record()
        self.save()

    def record(self):
        model = self.bike_sharing_model.model
        if model.SolCount > 0:
            computed_metrics = self.compute_decision_variable_result()
            (total_flow_by_mode, total_flow, average_travel_time, num_regular_bike_station, num_transfer_bike_station,
            regular_station_utilization, transfer_station_utilization,
            regular_station_borrowable_rate, regular_station_returnable_rate,
            transfer_station_borrowable_rate, transfer_station_returnable_rate,
            rebalance_intensity, total_rebalance_volume, average_rebalancing_distance) = computed_metrics
        else:
            (total_flow_by_mode, total_flow, average_travel_time, num_regular_bike_station, num_transfer_bike_station,
             regular_station_utilization, transfer_station_utilization,
             regular_station_borrowable_rate, regular_station_returnable_rate,
             transfer_station_borrowable_rate, transfer_station_returnable_rate,
             rebalance_intensity, total_rebalance_volume, average_rebalancing_distance) = (None,) * 14

        row = {
            "config": self.config_name,
            "od_num": self.bike_sharing_model.demand_generator.num_sampled_od_pairs,
            "total_demand": self.bike_sharing_model.demand_generator.total_trips,
            "total_budget": CostParameters.total_budget,
            "grid_size": f"{self.network.grid_generator.length}*{self.network.grid_generator.width}",
            "network_nodes": len(self.network.graph.nodes),
            "network_edges": len(self.network.graph.edges),
            "period": self.TIME_PERIODS,
            "n_candidates": len(self.network.bike_stations),
            "n_selected_stations": num_regular_bike_station + num_transfer_bike_station,
            "n_reg_station": num_regular_bike_station,
            "n_trans_station": num_transfer_bike_station,
            "util_reg": regular_station_utilization,
            "util_trans": transfer_station_utilization,
            "brw_reg": regular_station_borrowable_rate,
            "ret_reg": regular_station_returnable_rate,
            "brw_trans": transfer_station_borrowable_rate,
            "ret_trans": transfer_station_returnable_rate,
            "flow_total": total_flow,
            "avg_travel_time": average_travel_time,
            "coverage_rate": total_flow / self.TOTAL_TRIPS_NUN,
            "flow_bike_only": total_flow_by_mode["flow_bike_only"],
            "flow_bike_pt": total_flow_by_mode["flow_bike_pt"],
            "flow_walk_pt": total_flow_by_mode["flow_walk_pt"],
            "reb_budget": CostParameters.operational_budget,
            "reb_intensity": rebalance_intensity,
            "reb_vol": total_rebalance_volume,
            "reb_avg_dist": average_rebalancing_distance,
            "status": model.Status,
            "obj_val": round(model.ObjVal, 3) if model.SolCount > 0 else None,  # SolCount > 0 是最稳妥的判断是否“真的”有解的方式
            "obj_bound": round(model.ObjBound, 3) if model.SolCount > 0 else None,  # 通常 obj 都是有值的
            "gap": round(model.MIPGap, 3) if model.SolCount > 0 else None,  # Status = 9 (TIME_LIMIT) 不代表一定找到了可行解
            "runtime": round(model.Runtime, 3),
        }
        self.data.append(row)

    def compute_decision_variable_result(self):
        bss_model = self.bike_sharing_model
        # compute total flow by mode
        x_b = bss_model.x_b
        x_pt = bss_model.x_pt
        x_w = bss_model.x_w
        total_flow_by_mode = {
            "flow_bike_only": var_dict_sum(x_b),
            "flow_bike_pt": var_dict_sum(x_pt),
            "flow_walk_pt": var_dict_sum(x_w)
        }
        # compute number of stations by type (bike station, transfer station)
        y = bss_model.y
        v = bss_model.v
        w = bss_model.w
        r = bss_model.r
        bike_stations_selected = [s for s in y if y[s].X == 1]
        regular_bike_station = [s for s in bike_stations_selected if s.type == "BikeStation"]
        transfer_bike_station = [s for s in bike_stations_selected if s.type == "TransferStation"]
        num_regular_bike_station = len(regular_bike_station)
        num_transfer_bike_station = len(transfer_bike_station)
        # statistics of stations by type
        regular_station_utilization = self.compute_average_utilization_rate(regular_bike_station, v, w)
        transfer_station_utilization = self.compute_average_utilization_rate(transfer_bike_station, v, w)
        regular_station_borrowable_rate, regular_station_returnable_rate = self.compute_station_availability(
            regular_bike_station, v, w)
        transfer_station_borrowable_rate, transfer_station_returnable_rate = self.compute_station_availability(
            transfer_bike_station, v, w)

        # Rebalancing Intensity  越大说明越依赖后台调度 → 运营成本越高。
        total_rebalance_volume = sum(r[(i, j, t)].X for (i, j, t) in r if r[(i, j, t)].X > 1e-6)
        total_flow = var_dict_sum(x_b) + var_dict_sum(x_pt) + var_dict_sum(x_w)
        # todo: 为啥还会大于 1 呢，total_rebalance_volume 必然小于等于 total_flow 啊，大概资源太多 做了无谓的rebalancing 没有限制它
        rebalance_intensity = total_rebalance_volume / total_flow if total_flow > 0 else 0
        # average rebalancing distance
        total_rebalancing_distance = sum(
            r[(i, j, t)].X * euclidean_distance(i.coordinate, j.coordinate) for (i, j, t) in r if r[(i, j, t)].X > 1e-6)
        average_rebalancing_distance = total_rebalancing_distance / total_rebalance_volume if total_rebalance_volume > 0 else 0

        # average traveling time
        id_path_map = self.bike_sharing_model.shortest_path_solver.id_path_map
        total_travel_time = (self.compute_total_travel_time(x_b, id_path_map) + self.compute_total_travel_time
            (x_w, id_path_map) + self.compute_total_travel_time(x_pt, id_path_map))
        average_travel_time = total_travel_time / total_flow if total_flow > 0 else 0

        computed_metrics = (total_flow_by_mode, total_flow, average_travel_time, num_regular_bike_station,
                            num_transfer_bike_station,
                            regular_station_utilization, transfer_station_utilization,
                            regular_station_borrowable_rate, regular_station_returnable_rate,
                            transfer_station_borrowable_rate, transfer_station_returnable_rate,
                            rebalance_intensity, total_rebalance_volume, average_rebalancing_distance)
        return computed_metrics

    def save(self):
        df = pd.DataFrame(self.data, columns=self.columns)
        df = df.round(3)
        file_exists = os.path.exists(self.output_file)
        if file_exists:
            existing_df = pd.read_csv(self.output_file)
            df = pd.concat([existing_df, df], ignore_index=True)
        df.to_csv(self.output_file, index=False)

    def compute_total_travel_time(self, flow_var, id_path_map):
        return sum(flow_var[k, t, path].X * id_path_map[path].total_time for k, t, path in flow_var)

    def compute_average_utilization_rate(self, stations, v, w):
        """
        compute average utilization rate of selected stations (average of average inventory / capacity)
        do not consider period 0 because it's a dummy period
        :param stations:
        :param v: invertory level variable of each station
        :param w: capacity variable of each station
        :return:
        """
        utilization_sum = 0
        for station in stations:
            # 取出 station 在时间段 t 的库存变量（变量不存在则返回默认值 0）
            # single station, multi periods
            inv_sum = sum(v.get((station, t), 0).X for t in range(1, self.TIME_PERIODS + 1))
            avg_inventory = inv_sum / self.TIME_PERIODS
            utilization = avg_inventory / w.get(station).X
            utilization_sum += utilization
        utilization_rate = utilization_sum / len(stations) if stations else 0
        return utilization_rate

    def compute_station_availability(self, stations, v, w):
        """
        compute station availability rate (borrowable / returnable)
        :param stations:
        :param v:
        :param w:
        :return:
        """
        borrowable_index, returnable_index = 0, 0
        time_periods = range(1, self.TIME_PERIODS + 1)  # exclude period
        for station in stations:
            borrowable = sum(v.get((station, t), 0).X > 0 for t in time_periods)  # todo:可以设置成库存比例在一定范围内
            returnable = sum(v.get((station, t), 0).X < w.get(station).X for t in time_periods)
            borrowable_index += borrowable / len(time_periods)
            returnable_index += returnable / len(time_periods)
        # 计算平均值
        borrowable_index /= len(stations)
        returnable_index /= len(stations)
        return borrowable_index, returnable_index
