import json
from util.file_system import filesystem_instance
from util.util import get_tunable_params
from model.bike_sharing_optimization import BikeSharingModel

subdir = "map_data"
class VisualizeMap:
    def __init__(self, grid_generator, pt, demand_generator, model=BikeSharingModel):
        tp = get_tunable_params()
        self.grid, self.grid_centers = grid_generator.grid, grid_generator.grid_centers
        self.routes = pt.routes
        self.demand_generator = demand_generator
        self.model = model

    def export_all(self):
        self._export_grid()
        self._export_routes()
        self._export_bike_stations()
        self._export_od_trips()

    def _export_grid(self):
        """Save grid zones as GeoJSON-like format."""
        grid_features = []
        for node_id, (x, y) in self.grid_centers.items():
            feature = {
                "type": "Feature",
                "properties": {
                    "zone_id": node_id
                },
                "geometry": {
                    "type": "Point",
                    "coordinates": [x, y]
                }
            }
            grid_features.append(feature)

        data = {
            "type": "FeatureCollection",
            "features": grid_features
        }

        filename = filesystem_instance.get_output_path("grid.json", subdir=subdir)
        with open(filename, "w") as f:
            json.dump(data, f, indent=2)

    def _export_routes(self):
        """Save public transport routes as polylines."""
        route_features = []
        for route_name, stops in self.routes.items():
            coords = [stop.coordinate for stop in stops]
            feature = {
                "type": "Feature",
                "properties": {
                    "route_name": route_name
                },
                "geometry": {
                    "type": "LineString",
                    "coordinates": coords
                }
            }
            route_features.append(feature)

        data = {
            "type": "FeatureCollection",
            "features": route_features
        }

        filename = filesystem_instance.get_output_path("routes.json", subdir=subdir)
        with open(filename, "w") as f:
            json.dump(data, f, indent=2)

    def _get_station_features(self):
        station_features = []
        for bike_station in self.model.B:
            print(f"Bike station {bike_station.node_id} selected: {self.model.y[bike_station].X}")
            if self.model.y[bike_station].X == 1:  # Only stations actually selected
                coord = bike_station.coordinate
                capacity = self.model.w[bike_station].X
                inventory = self.model.v[bike_station, 0].X
                inventoryPerPeriod = {}
                for t in self.model.T:
                    inventoryPerPeriod[t] = self.model.v[bike_station, t].X

                feature = {
                    "type": "Feature",
                    "properties": {
                        "station_id": bike_station.node_id,
                        "capacity": capacity,
                        "inventory": inventoryPerPeriod
                    },
                    "geometry": {
                        "type": "Point",
                        "coordinates": coord
                    }
                }
                station_features.append(feature)
        return station_features
    
    def _get_flow_features(self):
        flow_features = []
        for t in self.model.T:
            for arc in self.model.A_bike_network.edges:
                start_node, end_node = arc
                quantity = self.model.f[start_node, end_node, t].X

                if quantity > 0:  # Only show actual flows
                    flow_feature = {
                        "type": "Feature",
                        "properties": {
                            "type": "flow",
                            "from": start_node.node_id,
                            "to": end_node.node_id,
                            "period": t,
                            "quantity": quantity
                        },
                        "geometry": {
                            "type": "LineString",
                            "coordinates": [
                                start_node.coordinate,
                                end_node.coordinate
                            ]
                        }
                    }
                    flow_features.append(flow_feature)
        return flow_features
    
    def _export_bike_stations(self):
        """Save optimized bike stations location and capacity."""
        if not self.model:
            return

        station_features = self._get_station_features()
        flow_features = self._get_flow_features()

        data = {
            "type": "FeatureCollection",
            "metadata": {
                "description": "Optimized bike stations and flows",
                "periods": list(self.model.T),
            },
            "features": station_features + flow_features
        }

        filename = filesystem_instance.get_output_path("bike_stations.json", subdir=subdir)
        with open(filename, "w") as f:
            json.dump(data, f, indent=2)

    def _export_od_trips(self):
        """Save demand OD pairs as directed links."""
        od_links = []
        for ((origin, destination), t), demand in self.demand_generator.demand_matrix.items():
            if demand > 0 and origin in self.grid_centers and destination in self.grid_centers:
                coord_origin = self.grid_centers[origin]
                coord_dest = self.grid_centers[destination]

                link = {
                    "origin": origin,
                    "destination": destination,
                    "coordinates": [coord_origin, coord_dest],
                    "demand": demand,
                    "period": t
                }
                od_links.append(link)

        filename = filesystem_instance.get_output_path("od_trips.json", subdir=subdir)
        with open(filename, "w") as f:
            json.dump(od_links, f, indent=2)
