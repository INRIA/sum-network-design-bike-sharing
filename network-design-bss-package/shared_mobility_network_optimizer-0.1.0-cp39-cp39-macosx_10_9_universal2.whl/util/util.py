import os
import pickle
import datetime
import numpy as np
import matplotlib.pyplot as plt
from util.file_system import filesystem_instance
from shared_mobility_network_optimizer.models import NetworkDesignBSSConfig

# ----------------------------------------------------------------
# tunable parameters
class TunableParameters:
    _instance = None

    def __init__(self):
        if TunableParameters._instance is not None:
            raise RuntimeError("Use get_tunable_params()")
        # number of shortest paths
        self.NUM_SHORTEST_PATHS = 3
        # Maximum allowed ratio a suboptimal path can exceed the theoretical optimal time
        self.MAX_RELATIVE_GAP = 0.2
        # proportion of OD pairs that are effectively serviced
        self.OD_COVERAGE_RATIO = 0.9
        # Area Size
        self.AREA_LENGTH = 8
        self.AREA_WIDTH = 8
        self.CELL_SIZE = 1
        # Radius to define the catchment area of two points by walking & biking
        self.WALK_CATCHMENT_RADIUS = 1      # 0.8 - 1.2 km
        self.RIDE_CATCHMENT_RADIUS = 4      # 2.5 - 5 km
        # Transfers between public transport modes are allowed within a certain distance threshold.
        self.PT_TRANSFER_RADIUS = 0.5       # 0.3 - 0.6 km
        # speed
        self.WALK_SPEED = 5                 # 4.5 - 5 km/h
        self.RIDE_SPEED = 15                # 12 - 18 km/h
        self.PUBLIC_TRANSPORT_SPEED = 30    # 20 - 35 km/h
        self.CAR_SPEED = 45                 # 35 - 50 km/h
        # demand for a single period
        self.TOTAL_TRIPS_NUN = 1000
        # period number
        self.TIME_PERIODS = 3
        # penalty coefficient for suboptimal path choice
        self.PENALTY_COEFFICIENT = 0.1
        # capacity upper bound of each bike station
        self.CAPACITY_UB = 30
        # Fixed route public transit (PT station located within partitioned sub-zones and indexed accordingly)
        self.FIXED_LINE_POINTS_LST = [[10, 18, 27, -1, 36, 45, 53], [22, 21, 28, -1, 35, 42, 41]]
        # is rebalancing considered
        self.REBALANCING_FLAG = True
        TunableParameters._instance = self

    def update_from_config(self, config: NetworkDesignBSSConfig):
        self.__dict__.update(config.model_dump())
        return self

def init_tunable_params(config: NetworkDesignBSSConfig):
    return get_tunable_params().update_from_config(config)

def get_tunable_params() -> TunableParameters:
    if TunableParameters._instance is None:
        TunableParameters()
    return TunableParameters._instance


# ----------------------------------------------------------------
# default parameters

# detour ratio 提升此比例能提高任何 k 的结果质量 因此也不是关键影响因素
DETOUR_RATIO = 1.2
# punishment mode (ranking based/ magnitude and ratio based)
IS_RANKING_BASED = True
# 控制 短途 vs 长途的权衡，调整短途变化过敏感 vs 长途变化不敏感问题
TIME_SENSITIVITY = 20
# 控制路径质量的要求
RISK_TOLERANCE = 0.8
# customized constraints (最多一个为 True)
ARC_BASED_CONSTRAINTS = False
STATION_BASED_CONSTRAINTS = True
# Shortest path result cache path
SAVE_DIR = "data/shortest_paths_result"
# Path to statistical results output
timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
OUTPUT_CSV_FILE = f"optimization_statistics_results_{timestamp}.csv"

OUTPUT_COLUMNS = [
    "config", "od_num", "total_demand", "total_budget", "grid_size", "network_nodes", "network_edges",
    "period", "n_candidates", "n_selected_stations", "n_reg_station", "n_trans_station",
    "util_reg", "util_trans", "brw_reg", "ret_reg", "brw_trans", "ret_trans",
    "flow_total", "avg_travel_time", "coverage_rate", "flow_bike_only", "flow_bike_pt", "flow_walk_pt",
    "reb_budget", "reb_intensity", "reb_vol", "reb_avg_dist",
    "status", "obj_val", "obj_bound", "gap", "runtime"
]


def add_input_cwd(file_name):
    return os.path.join(os.getcwd(), 'data', 'input', '0101', file_name)


def add_output_cwd(file_name, subdir=None):
    return os.path.join(os.getcwd(), 'data', 'output', subdir, file_name)


def add_specific_cwd(file_name, directory):
    return os.path.join(os.getcwd(), 'data', directory, file_name)


def add_config_cwd(file_name, directory):
    return os.path.join(os.getcwd(), directory, file_name)


def add_plot_cwd(file_name):
    return os.path.join(os.getcwd(), 'plot', file_name)


def save_results_to_pickle(filename, data):
    """将计算结果存入 pickle 文件"""
    full_path = filesystem_instance.get_shortest_path_cache_path(filename)
    with open(full_path, 'wb') as f:
        pickle.dump(data, f)


def load_results_from_pickle(filename):
    """从 pickle 文件加载计算结果"""
    full_path = filesystem_instance.get_shortest_path_cache_path(filename)
    with open(full_path, 'rb') as f:
        return pickle.load(f)


def euclidean_distance(coord1, coord2):
    """
    Calculate Euclidean distance between two coordinates.
    :param coord1: (x1, y1)
    :param coord2: (x2, y2)
    :return: Euclidean distance
    """
    return ((coord1[0] - coord2[0]) ** 2 + (coord1[1] - coord2[1]) ** 2) ** 0.5


def var_dict_sum(dic):
    """
    :param dic:
    :return: sum of all values in the dictionary
    """
    return sum(var.X for var in dic.values())


def generate_peak_weights(periods, peak_strength=5):
    """
    todo：A bimodal distribution can be fitted to real-world data in
     order to capture the typical demand patterns, such as morning and evening peaks
    根据 period 数自动生成一组时间段权重，使早晚高峰权重更高。
    :param periods: int, 时间段数量
    :param peak_strength: float, 越大峰值越明显
    :return: list of weights
    """
    # 构造双峰函数：两边高，中间低（钟形镜像）
    x = np.linspace(0, 1, periods)  # 标准化时间段
    left_peak = np.exp(-peak_strength * (x - 0.0) ** 2)
    right_peak = np.exp(-peak_strength * (x - 1.0) ** 2)
    weights = left_peak + right_peak
    weights = weights / np.sum(weights)
    return weights.tolist()


def generate_single_peak_weights(periods, decay_strength=2.0):
    """
    生成一个单峰的时间权重分布，峰值在第一期，之后呈现逐步下降趋势。

    参数：
    - periods: 总期数
    - decay_strength: 控制下降的快慢，越大下降越快（建议值 1~5）
    """
    x = np.arange(periods)
    weights = np.exp(-decay_strength * x / (periods - 1))  # 从第0期开始逐步下降
    weights /= np.sum(weights)  # 归一化为概率
    return weights.tolist()


def generate_strict_peak_weights(periods, peak_strength=15):
    """
    生成早晚高峰权重分布，确保双峰在period较小时也保持明显。
    """
    x = np.linspace(0, 1, periods)

    # 将峰值偏移至靠近0.2和0.8，更适合3–8个period
    left_peak = np.exp(-peak_strength * (x - 0.2) ** 2)
    right_peak = np.exp(-peak_strength * (x - 0.8) ** 2)

    # 叠加后压低中间区域（例如人为乘以一个收缩因子）
    weights = left_peak + right_peak
    if periods <= 5:
        # 手动降低中间值权重，确保双峰（只在 period 少时启用）
        center_idx = periods // 2
        weights[center_idx] *= 0.4  # 你可以调这个参数
    elif periods == 6:
        weights[2:4] *= 0.7
    elif periods == 7:
        weights[3] *= 0.6
    elif periods == 8:
        weights[3:5] *= 0.7

    weights /= np.sum(weights)
    return weights.tolist()


