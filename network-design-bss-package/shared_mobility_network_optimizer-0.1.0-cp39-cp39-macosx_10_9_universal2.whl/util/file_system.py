import os
import datetime

class FileSystem:
    def __init__(self, destination_root_path="data", cache_folder="cache", input_data_folder="input_data",
                 model_result_folder="model", shortest_path_result_folder="shortest_paths_result"):
        """
        Initialize the FileSystem class with default or custom folder paths.
        """
        self.destination_root_path = destination_root_path
        self.cache_folder = cache_folder
        self.input_data_folder = input_data_folder
        self.model_result_folder = model_result_folder
        self.shortest_path_result_folder = shortest_path_result_folder
        self.destination_path = None
        self.cache_path = None
        self.input_data_path = None
        self.model_destination_path = None
        self.shortest_path_destination_path = None

    def create_folder(self, path):
        """
        Recursively create a folder and its parent directories if they do not exist.
        :param path: str, the path to create
        """
        if not os.path.exists(path):
            os.makedirs(path)

    def init_destination_path(self, path=None, default_cache_path=None):
        """
        Initialize the destination path for output files.
        :param path: str, custom path to save the output files
        :param default_cache_path: str, custom cache path
        :return: tuple, paths for destination, input data, model results, and shortest path cache
        """
        path = path or self.destination_root_path
        default_cache_path = default_cache_path or self.destination_root_path

        execution_folder_timestamp = "execution_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.destination_path = os.path.join(path, execution_folder_timestamp)
        self.cache_path = os.path.join(default_cache_path, self.cache_folder)

        # Create the destination path if it does not exist
        self.create_folder(self.destination_path)
        self.create_folder(self.cache_path)

        self.input_data_path = os.path.join(self.destination_path, self.input_data_folder)
        self.model_destination_path = os.path.join(self.destination_path, self.model_result_folder)
        self.shortest_path_destination_path = os.path.join(self.cache_path, self.shortest_path_result_folder)

        # Create subdirectories for different types of output
        self.create_folder(self.input_data_path)
        self.create_folder(self.model_destination_path)
        self.create_folder(self.shortest_path_destination_path)

        return (self.destination_path, self.input_data_path, self.model_destination_path,
                self.shortest_path_destination_path)

    def get_output_path(self, filename=None, subdir=None):
        """
        Get the output path for the current execution.
        :param filename: str, optional filename
        :param subdir: str, optional subdirectory
        :return: str, the output path
        """
        if subdir is not None:
            self.create_folder(os.path.join(self.destination_path, subdir))
        if filename is None:
            return os.path.join(self.destination_path, subdir) if subdir else self.destination_path
        else:
            return os.path.join(self.destination_path, subdir, filename) if subdir else os.path.join(self.destination_path, filename)

    def get_output_model_path(self, filename=None, subdir=None):
        """
        Get the output model path for the current execution.
        :param filename: str, optional filename
        :param subdir: str, optional subdirectory
        :return: str, the output model path
        """
        if filename is None:
            return os.path.join(self.model_destination_path, subdir) if subdir else self.model_destination_path
        else:
            return os.path.join(self.model_destination_path, subdir, filename) if subdir else os.path.join(self.model_destination_path, filename)

    def get_input_path(self, filename=None, subdir=None):
        """
        Get the input path for the current execution.
        :param filename: str, optional filename
        :param subdir: str, optional subdirectory
        :return: str, the input path
        """
        if filename is None:
            return os.path.join(self.input_data_path, subdir) if subdir else self.input_data_path
        else:
            return os.path.join(self.input_data_path, subdir, filename) if subdir else os.path.join(self.input_data_path, filename)

    def get_cache_path(self, filename=None, subdir=None):
        """
        Get the cache path for the current execution.
        :param filename: str, optional filename
        :param subdir: str, optional subdirectory
        :return: str, the cache path
        """
        if filename is None:
            return os.path.join(self.cache_path, subdir) if subdir else self.cache_path
        else:
            return os.path.join(self.cache_path, subdir, filename) if subdir else os.path.join(self.cache_path, filename)

    def get_shortest_path_cache_path(self, filename=None, subdir=None):
        """
        Get the shortest path cache path for the current execution.
        :param filename: str, optional filename
        :param subdir: str, optional subdirectory
        :return: str, the shortest path cache path
        """
        if filename is None:
            return os.path.join(self.shortest_path_destination_path, subdir) if subdir else self.shortest_path_destination_path
        else:
            return os.path.join(self.shortest_path_destination_path, subdir, filename) if subdir else os.path.join(self.shortest_path_destination_path, filename)
        

filesystem_instance = FileSystem()
filesystem_instance.init_destination_path()

def init_custom_file_system(destination_root_path=None, cache_folder=None, input_data_folder=None,
                                 model_result_folder=None, shortest_path_result_folder=None):
    """
    Initialize a custom file system with user-defined folder paths.
    :param destination_root_path: str, root path for output files
    :param cache_folder: str, name of the cache folder
    :param input_data_folder: str, name of the input data folder
    :param model_result_folder: str, name of the model result folder
    :param shortest_path_result_folder: str, name of the shortest path result folder
    """
    global filesystem_instance
    filesystem_instance = FileSystem(destination_root_path, cache_folder, input_data_folder,
                                     model_result_folder, shortest_path_result_folder)
    filesystem_instance.init_destination_path()
    return filesystem_instance